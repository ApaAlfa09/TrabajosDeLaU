package com.prograll.ProjectSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
