import autoprefixer from "autoprefixer";
import { plugin } from "postcss";

export default{
    plugins: {
        '@tailwindcss/postcss': {},
        autoprefixer: {},
    },
}