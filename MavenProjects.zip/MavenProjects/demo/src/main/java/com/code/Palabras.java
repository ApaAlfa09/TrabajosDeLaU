package com.code;
public class Palabras {
    private String palabraEspa;
    private String palabraIngle;
    
    public Palabras(String palabraEspa, String palabraIngle) {
        this.palabraEspa = palabraEspa;
        this.palabraIngle = palabraIngle;
    }

    public String getPalabraEspa() {
        return palabraEspa;
    }
    public void setPalabraEspa(String palabraEspa) {
        this.palabraEspa = palabraEspa;
    }

    public String getPalabraIngle() {
        return palabraIngle;
    }
    public void setPalabraIngle(String palabraIngle) {
        this.palabraIngle = palabraIngle;
    }

    
}
