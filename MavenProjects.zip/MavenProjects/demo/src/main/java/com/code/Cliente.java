package com.code;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) {
        try (
            Socket socket = new Socket("localhost", ConfiPuerto.getInstance().getPort());
            BufferedReader lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter escritor = new PrintWriter(socket.getOutputStream(), true);
            Scanner teclado = new Scanner(System.in);
        ) {
            String message;
            String palabra;
            message = lector.readLine();
            System.out.println(message);
            while ((message = lector.readLine()) != null) {
                System.out.println(message);
                palabra = teclado.nextLine();
                escritor.println(palabra);

                

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
