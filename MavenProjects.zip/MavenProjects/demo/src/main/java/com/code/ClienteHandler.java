package com.code;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class ClienteHandler implements Runnable{
    private List<Palabras> palabras;
    private Socket cliente;

    public ClienteHandler(List<Palabras> palabras, Socket cliente) {
        this.palabras = palabras;
        this.cliente = cliente;
    }
    
    @Override
    public void run() {
        String message;
        try {
            BufferedReader lector = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            PrintWriter escritor = new PrintWriter(cliente.getOutputStream());
            escritor.println("Ingrese alguna palabra");
            while (true) { 
                

                message = lector.readLine();
                


                if (message.equalsIgnoreCase("salir")) {
                    escritor.println("Saliendo");
                    break;
                }
                
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
}
