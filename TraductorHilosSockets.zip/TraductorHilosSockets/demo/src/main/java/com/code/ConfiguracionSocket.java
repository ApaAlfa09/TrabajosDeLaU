package com.code;
public class ConfiguracionSocket {

    private static ConfiguracionSocket intance;
    private static int port = 4001;

    private ConfiguracionSocket() {

    }

    public static ConfiguracionSocket getIntance() {
        if (intance == null) {
            intance = new ConfiguracionSocket();
        }
            return intance;
        
    }

    public int getPort() {
        return port;
    }
}
