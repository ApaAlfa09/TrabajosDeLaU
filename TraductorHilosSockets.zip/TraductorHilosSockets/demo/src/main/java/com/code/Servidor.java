package com.code;
public class Servidor {
    public static void main(String[] args) {
        ServidorTraductor servidor = new ServidorTraductor();
        servidor.iniciarServidor();
    }
}
