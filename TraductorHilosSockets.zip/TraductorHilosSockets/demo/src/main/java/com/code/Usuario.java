package com.code;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Usuario {
    public static void main(String[] args) {
        try (
                Socket socket = new Socket("localhost", ConfiguracionSocket.getIntance().getPort());
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                Scanner scanner = new Scanner(System.in);) {

            ObjectMapper mapper = new ObjectMapper();

            System.out.println(reader.readLine()); // Mensaje de bienvenida

            String message;
            while (true) {
                System.out.print("Español: ");
                message = scanner.nextLine();
                writer.println(message);
                if (message.equalsIgnoreCase("salir"))
                    break;

                String respuesta = reader.readLine();
                System.out.println("IA: " + respuesta);

                if (respuesta.contains("me puede brindar el valor en inglés")) {
                    System.out.print("Traducción en inglés: ");
                    String nuevaTraduccion = scanner.nextLine();
                    writer.println(nuevaTraduccion);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
