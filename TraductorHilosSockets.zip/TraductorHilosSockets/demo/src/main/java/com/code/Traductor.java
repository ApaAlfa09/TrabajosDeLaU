package com.code;
public class Traductor {

    private String palabraEspanol;
    private String palabraIngles; 

    public Traductor() {
        super();
    }

    public Traductor(String palabraEspanol, String palabraIngles) {
        this.palabraEspanol = palabraEspanol;
        this.palabraIngles = palabraIngles; 
    }

    public String getPalabraEspanol() {
        return palabraEspanol;
    }

    public String getPalabraIngles() {
        return palabraIngles;
    }

    public void setPalabraEspanol(String palabraEspanol) {
        this.palabraEspanol = palabraEspanol;
    }

    public void setPalabraIngles(String palabraIngles) {
        this.palabraIngles = palabraIngles;
    }

    @Override
    public String toString() {
        return palabraEspanol + ": " + palabraIngles;
    }
}