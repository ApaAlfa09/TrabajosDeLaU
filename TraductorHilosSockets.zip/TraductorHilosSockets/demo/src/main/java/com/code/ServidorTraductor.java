package com.code;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ServidorTraductor {
    private static List<Traductor> listaTraductor;

    public ServidorTraductor() {
        listaTraductor = new ArrayList<>();
    }

    public void iniciarServidor() {
        listaTraductor = leerLista();
        try (ServerSocket serverSocket = new ServerSocket(ConfiguracionSocket.getIntance().getPort())) {
            System.out.println("Esperando");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Aceptó");
                new Thread(new ManejadorClienteTraductor(socket, listaTraductor)).start();
            }
        } catch (Exception e) {
            System.out.println(e);
            ;
        }

    }

    private List<Traductor> leerLista() {
        ObjectMapper mapper = new ObjectMapper();
        List<Traductor> palabras = new ArrayList<>();

        try {
            palabras = mapper.readValue(new File("diccionario.json"), new TypeReference<List<Traductor>>() { });
            System.out.println("Lista cargada");
            System.out.println(palabras);
            return palabras;
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Lista no existe");
        }

        return palabras;
    }
}
