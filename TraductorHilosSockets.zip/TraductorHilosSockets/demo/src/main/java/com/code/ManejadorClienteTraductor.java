package com.code; 
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ManejadorClienteTraductor implements Runnable {

    private Socket socket;
    private List<Traductor> lista;

    public ManejadorClienteTraductor(Socket socket, List<Traductor> lista) {
        this.socket = socket;
        this.lista = lista;
    }

    @Override
    public void run() {
        try (
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));) {
                          ObjectMapper mapper = new ObjectMapper();

            writer.println("Bienvenido al AI traductor qué quiere traducir de español a inglés.");

            String palabra;
            while ((palabra = reader.readLine()) != null) {
                System.out.println(palabra);

                if (palabra.equals("salir")) {
                    break;
                }

                if (buscarPalabra(palabra)) {
                    writer.println(obtenerPalabra(palabra));
                } else {
                    writer.println("No cuento con esa información me puede brindar el valor en inglés");
                    String nueva = reader.readLine();
                    lista.add(new Traductor(palabra, nueva));

                }
            }
            saveToFile(mapper);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

     private boolean buscarPalabra(String palabra) {
        return lista.stream().anyMatch(el -> el.getPalabraEspanol().equalsIgnoreCase(palabra));
    }

    private  String obtenerPalabra(String palabra) {
        String traduccion = lista.stream()
                .filter(t -> t.getPalabraEspanol().equalsIgnoreCase(palabra))
                .findFirst()
                .map(Traductor::getPalabraIngles)
                .orElse("No tengo esa palabra.");
         return traduccion;
    }

    private void saveToFile(ObjectMapper mapper) {
        try {
            mapper.writeValue(new File("diccionario.json"), lista);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    

}
