public abstract class VehicleFactory {
    abstract Vehicle createVehicle(String brand, String model, double price);
}
