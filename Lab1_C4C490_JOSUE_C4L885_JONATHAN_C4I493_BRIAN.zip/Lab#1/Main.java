public class Main {
    public static void main(String[] args) {
        CompanyManager companyManager = new CompanyManager();
        companyManager.run();
    }
}
